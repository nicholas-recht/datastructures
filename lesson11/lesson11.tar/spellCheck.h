/***********************************************************************
 * Module:
 *    Lesson 11, Spell Check
 *    Brother Helfrich, CS 235
 * Author:
 *    Nicholas Recht
 * Summary:
 *    This program will implement the spellCheck() function
 ************************************************************************/

#ifndef SPELL_CHECK_H
#define SPELL_CHECK_H

void spellCheck();


#endif // SPELL_CHECK_H
